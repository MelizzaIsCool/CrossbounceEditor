﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Directions : MonoBehaviour
{
    [Space]
    [Header("-----------------------CONTROLS----------------------")]
    [Space]
    [Header("1.Arrow keys to transform object")]
    [Space]
    [Header("2.Space bar to cycle through different transformations")]
    [Space]
    [Space]
    public bool directions;

    

    private void Start()
    {
        
    }
}
