﻿using UnityEngine;
using UnityEditor;
using System.Text;

public class ObstacleEditor : EditorWindow
{
    private static ObstacleEditor instance;

    public static void ShowWindow()
    {
        instance = EditorWindow.GetWindow<ObstacleEditor>();
        instance.titleContent = new GUIContent("Level Editor");
    }

    private void OnGUI()
    {
        //bounciness = EditorGUILayout.FloatField("Bounciness", bounciness);
        if (GUILayout.Button("Create Wall"))
        {
            //First fetch Guid assets
            string[] obstacleGuids = AssetDatabase.FindAssets("prefab_Wall");
            StringBuilder guiBuilder = new StringBuilder();

            foreach (string obstacle in obstacleGuids)
            {
                guiBuilder.AppendLine(obstacle);
            }

            if (obstacleGuids.Length > 0)
            {
                string trueObstacleGuids = obstacleGuids[0];
                //get the assets oath from the guid
                string assetPath = AssetDatabase.GUIDToAssetPath(trueObstacleGuids);
                //Get the object itself
                GameObject wallTemp = AssetDatabase.LoadAssetAtPath(assetPath, typeof(GameObject)) as GameObject;
                GameObject newWall = GameObject.Instantiate(wallTemp);
                newWall.name = wallTemp.name;
                PhysicsMaterial2D physMat = new PhysicsMaterial2D();
                newWall.GetComponent<Collider2D>().sharedMaterial = physMat;
            }
        }


        if (GUILayout.Button("Create Target"))
        {
            //First fetch Guid assets
            string[] obstacleGuids = AssetDatabase.FindAssets("prefab_Target");
            StringBuilder guiBuilder = new StringBuilder();

            foreach (string obstacle in obstacleGuids)
            {
                guiBuilder.AppendLine(obstacle);
            }

            if (obstacleGuids.Length > 0)
            {
                string trueObstacleGuids = obstacleGuids[0];
                //get the assets oath from the guid
                string assetPath = AssetDatabase.GUIDToAssetPath(trueObstacleGuids);
                //Get the object itself
                GameObject targetTemp = AssetDatabase.LoadAssetAtPath(assetPath, typeof(GameObject)) as GameObject;
                GameObject newTarget = GameObject.Instantiate(targetTemp);
                newTarget.name = targetTemp.name;
            }
        }
    }
}
